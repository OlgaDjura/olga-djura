<template>
<div class="container">
    <header logo="require('@/assets/imge/Logo 1.png')" :links="navLinks"></header>
        <section>
            <div class="big-banner-page4">
                <img src="require('@/assets/imges/banner-page4.png')" alt="banner" class="banner-page4">
                <div class="text-big-banner-page4">
                    <h1>Наш проект</h1><br>
                    <p>Домой / Проект</p>
                </div>
            </div>
        </section>
        <section>
            <div class="content-btn-page4">
                <button class="merged-button" onclick="location.href='#'">Ванная комната</button>
                <button class="merged-button" onclick="location.href='#'">Спальня</button>
                <button class="merged-button" onclick="location.href='#'">Кухня</button>
                <button class="merged-button" onclick="location.href='#'">Гостиная</button>
            </div>
            <div class="badroom-imgeAll-page4">
                <div class="column1">
                    <div class="badroom-imge1-page4">
                        <div class="star1">
                            <img class="imge1-page4" src="require('@/assets/imges/badroom-imge1-page4.png')" alt="imge1">
                            <img src="require('@/assets/imges/Star page4.png')" alt="star" class="star">
                        </div>
                        <div class="text-button-page4">
                            <div class="text-imge-page4">
                                <h3>Минималиистичная спальня</h3>
                                <p>
                                    Декор / Планировка
                                </p>
                            </div>

                            <button class="btn-badroom-page4">&gt</button>
                        </div>
                    </div>
                    <div class="badroom-imge3-page4">
                        <div class="star2">
                            <img class="imge3-page4" src="require('@/assets/imges/badroom-imge3-page4.png')" alt="imge1">
                            <img src="require('@/assets/imges/Star page4.png')" alt="star" class="starI">
                        </div>
                        <div class="text-button-page4">
                            <div class="text-imge-page4">
                                <h3>Классическая спальня</h3>
                                <p>
                                    Декор / Планировка
                                </p>
                            </div>
                            <button class="btn-badroom-page4">&gt</button>
                        </div>
                    </div>
                    <div class="badroom-imge5-page4">
                        <img class="imge5-page4" src="require('@/assets/imges/badroom-imge5-page4.png')" alt="imge1">
                        <div class="text-button-page4">
                            <div class="text-imge-page4">
                                <h3>Минималиистичный прикроватный столик</h3>
                                <p>
                                    Декор / Планировка
                                </p>
                            </div>

                            <button class="btn-badroom-page4">&gt</button>
                        </div>
                    </div>
                    <div class="badroom-imge7-page4">
                        <img class="imge7-page4" src="require('@/assets/imges/badroom-imge7-page4.png')" alt="imge1">
                        <div class="text-button-page4">
                            <div class="text-imge-page4">
                                <h3>Современная спальня</h3>
                                <p>
                                    Декор / Планировка
                                </p>
                            </div>
                            <button class="btn-badroom-page4">&gt</button>
                        </div>
                    </div>

                </div>
                <div class="column2">
                    <div class="badroom-imge2-page4">
                        <img class="imge2-page4" src="require('@/assets/imges/badroom-imge2-page4.png')" alt="imge1">
                        <div class="text-button-page4">
                            <div class="text-imge-page4">
                                <h3>Минималиистичная спальня</h3>
                                <p>
                                    Декор / Планировка
                                </p>
                            </div>
                            <button class="btn-badroom-page4">&gt</button>
                        </div>
                    </div>
                    <div class="badroom-imge4-page4">
                        <img class="imge4-page4" src="require('@/assets/imges/badroom-imge4-page4.png')" alt="imge1">
                        <div class="text-button-page4">
                            <div class="text-imge-page4">
                                <h3>Современная спальня</h3>
                                <p>
                                    Декор / Планировка
                                </p>
                            </div>
                            <button class="btn-badroom-page4">&gt</button>
                        </div>
                    </div>
                    <div class="badroom-imge6-page4">
                        <img class="imge6-page4" src="require('@/assets/imges/badroom-imge6-page4.png')" alt="imge1">
                        <div class="text-button-page4">
                            <div class="text-imge-page4">
                                <h3>Столы и столики</h3>
                                <p>
                                    Декор / Планировка
                                </p>
                            </div>
                            <button class="btn-badroom-page4">&gt</button>
                        </div>
                    </div>
                    <div class="badroom-imge8-page4">
                        <img class="imge8-page4" src="require('@/assets/imges/badroom-imge8-page4.png')" alt="imge1">
                        <div class="text-button-page4">
                            <div class="text-imge-page4">
                                <h3>Современная спальня</h3>
                                <p>
                                    Декор / Планировка
                                </p>
                            </div>
                            <button class="btn-badroom-page4">&gt</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="pagination">
            <button class="btn-pagination">01</button>
            <button>02</button>
            <button>03</button>
            <button>&gt</button>
        </div>

        <footer
                logo1="require('@/assets/imges/Logo 1.png')"
                logo2="require('@/assets/imges/ikon 1.png')" 
                logo3="require('@/assets/imges/icon 2.png')"
                :pageLinks="navLinks"
                :contacts="contactInfo"></footer>

    </div>
</template>

<script>
import header from './header.vue';
import footer from './footer.vue';
export default {
    name: 'page4',
    components: {
        header,
        footer,
    },
    data() {
        return {
            navLinks: [
                { name: 'Домой', href: 'page3.vue' },
                { name: 'Проект', href: 'page4.vue'},
                { name: 'Блок', href: 'page5.vue'}
            ],
            contactInfo: {
                adress: '55 East Birchwood Ave. <br> Brooklyn, New York 11201',
                email: 'contact@interno.com',
                phone: '(123) 456-7890'
            }
        };
    }
};
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Jost:ital,wght@0,100..900;1,100..900&display=swap');

* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    /* Correction: use border-box instead of 0 */
    text-decoration: none;
}

.container {
    max-width: 1200px;
    margin: auto;

}


.banner-page4 {
    width: 1920px;
    height: 356px;
    margin-left: -380px;
}

.big-banner-page4 {
    position: relative;
}

.text-big-banner-page4 {
    position: absolute;
    width: 503px;
    height: 274px;
    border-radius: 37px 37px 0px 0px;
    background: rgb(255, 255, 255);
    padding: 41px 78px 41px 78px;
    top: 50%;
    right: 30%;
}

.text-big-banner-page4 h1 {
    color: rgb(41, 47, 54);
    font-family: DM Serif Display;
    font-size: 50px;
    font-weight: 400;
}

.text-big-banner-page4 p {
    color: rgb(77, 80, 83);
    font-family: Jost;
    font-size: 22px;
    font-weight: 400;
    margin-left: 90px;
}

.content-btn-page4 {
    margin-top: 200px;
    display: flex;

}

.badroom-imgeAll-page4 {
    margin-top: 50px;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}

.imge1-page4 {
    width: 585px;
    height: 853px;
}

.imge2-page4 {
    width: 586px;
    height: 522px;
}

.imge3-page4 {
    width: 585px;
    height: 522px;
}

.imge4-page4 {
    
    width: 586px;
    height: 853px;
}

.imge5-page4 {
    width: 585px;
    height: 853px;
}

.imge6-page4 {
    width: 586px;
    height: 522px;
}

.imge7-page4 {
    width: 585px;
    height: 522px;
}

.imge8-page4 {
    width: 585px;
    height: 522px;
}

.text-button-page4 h3 {
    margin-top: 20px;
    color: rgb(41, 47, 54);
    font-family: DM Serif Display;
    font-size: 25px;
}

.text-button-page4 p {

    color: rgb(77, 80, 83);
    font-family: Jost;
    font-size: 22px;

}

.text-button-page4 {
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
    margin-bottom: 20px;
}

.btn-badroom-page4 {
    margin-top: 20px;
    width: 70px;
    height: 70px;
    border-radius: 50%;
    border: none;
    color: rgb(30, 28, 28);
    cursor: pointer;
    font-size: 20px;
    background-color: rgb(244, 240, 236);
}
.badroom-imge4-page4 {
    padding-top: -100PX;
}

.content-btn-page4 {
    width: 880px;
height: 75px;
margin-left: 120px;
    display: flex;
    overflow: hidden;
    border-radius: 18px; 
    border: 2px solid;
    border-color: rgb(205, 162, 116);
    background-color: rgb(250, 250, 250);
}
.merged-button {
    flex: 1;
    border: none;
    color: rgb(41, 47, 54);
    cursor: pointer;
    transition: 0.3s;
}
.merged-button:hover {
    background-color:
    rgb(205, 162, 116);
    color: azure;
    border-radius: 18px;
}
.merged-button:first-child {
    border-top-left-radius: 18px;
    border-bottom-left-radius: 18px;
}
.merged-button:last-child {
    border-top-right-radius: 18px;
    border-bottom-right-radius: 18px;
}
.star1, .star2 {
    position: relative;
}
.star, .starI {
    position: absolute;
    width: 36px;
height: 34px;
}
.star {
    top: 0;
    right: 10px;
}
.starI {
    top: -63%;
    right: -610px;
}



.pagination {
    display: flex;
    justify-content: center;
    margin-top: 100px;
    gap: 20px;

}

.pagination button {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    cursor: pointer;
    font-family: Jost;
    font-size: 16px;
    border-color: rgb(232, 213, 194);
    background-color: rgb(255, 255, 255);
}

.btn-pagination {
    background-color: rgb(244, 240, 236);
}
</style>