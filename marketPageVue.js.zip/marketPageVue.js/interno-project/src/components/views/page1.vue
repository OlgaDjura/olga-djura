<template>
<div class="conteiner">
    <header logo="require('@/assets/imge/Logo 1.png')" :links="navLinks"></header>

        <section>
            <div class="banner-conteiner">
                <img class="banner" src="require('@/assets/imges/banner 1 главный.png')" alt="banner">
                <div class="content-banner">
                    <h1>Пусть ваш дом
                        <br>
                        будет уникальным
                    </h1>
                    <p class="text-banner">
                        Существует много вариантов Lorem Ipsum,
                        <br>
                        которые можно использовать
                    </p>
                    <button class="btn-banner" onclick="location.href='page2.html'">Начать</button>
                </div>
            </div>
        </section>
        <section class="project-section">
            <div class="project">
                <div class="project-text">
                    <h1>Следите за нашими проектами</h1>
                    <br>
                    <p>Хорошо известно, что читатель будет отвлекаться
                        <br>
                        на читабельный контент страницы
                    </p>
                </div>
                <div class="project-imge">
                    <div class="primge1">
                        <img class="project1" src="require('@/assets/imges/images 1.png')" alt="imge1">
                        <div class="text-button">
                            <p>Современная кухня
                                <br>
                                Декор / Планировка
                            </p>
                            <button class="btn-project1">&gt</button>
                        </div>
                    </div>
                    <div class="PrImge2">
                        <img class="project2" src="require('@/assets/imges/Image 2.png')" alt="imge2">
                        <div class="text-button">
                            <p>Современная кухня
                                <br>
                                Декор / Планировка
                            </p>
                            <button class="btn-project2">&gt</button>
                        </div>
                    </div>
                    <div class="PrImge3">
                        <img class="project3" src="require('@/assets/imges/Image 3.png')" alt="imge3">
                        <div class="text-button">
                            <p>Современная кухня
                                <br>
                                Декор / Планировка
                            </p>
                            <button class="btn-project3">&gt</button>
                        </div>
                    </div>
                    <div class="PrImge4">
                        <img class="project4" src="require('@/assets/imge/Image 4.png')" alt="imge4">
                        <div class="text-button">
                            <p>Современная кухня
                                <br>
                                Декор / Планировка
                            </p>
                            <button class="btn-project4">&gt</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="counter">
            <div class="allnumber">
                <div class="imge12">
                    <img class="number12" src="require('@/assets/imges/12.png')" alt="12">
                    <p>Лет опыта</p>

                </div>
                <div class="imge85">
                    <img class="number85" src="require('@/assets/imges/85.png')" alt="85">
                    <p>Успешных проектов</p>

                </div>
                <div class="imge15">
                    <img class="number15" src="require('@/assets/imges/15.png')" alt="15">
                    <p>Проектов в работе</p>

                </div>
                <div class="95">
                    <img class="number95" src="require('@/assets/imges/95.png'')" alt="95">
                    <p>Счастливых клиентов</p>

                </div>
            </div>
        </section>
        <section class="blog">
            <div class="blog-title">
                <h1>Статьи [&] <br> Новости</h1>
                <p>Хорошо известно, что читатель будет отвлекаться <br> на читабельный контент страницы</p>
            </div>
            <div class="blog-images">
                <div class="blog-imge1">
                    <img class="imge-blog" src="require('@/assets/imges/ImageBlog1.png')" alt="картинка1">
                    <div class="tag">
                        <p>Дизайн кухни</p>
                    </div>
                    <p class="blog-text1">Создадим лучший макет перепланировки</p>
                    <div class="data">
                        <p>26 Декабрь,2022</p>
                        <button class="btn-blog1">&gt</button>
                    </div>
                </div>
                <div class="blog-imge2">
                    <img class="imge-blog" src="require('@/assets/imges/ImageBlog2.png')" alt="картинка2">
                    <div class="tag2">
                        <p>Дизайн для жизни</p>
                    </div>
                    <p class="blog-text2">Лучшие интерьерные идеи по низкой цене</p>
                    <div class="data2">
                        <p>22 Декабрь,2022 </p>
                        <button class="btn-blog2">&gt</button>
                    </div>
                </div>
                <div class="blog-imge3">
                    <img class="imge-blog" src="require('@/assets/imges/ImageBlog3.png')" alt="картинка3">
                    <div class="tag3">
                        <p>Дизайн интерьера</p>
                    </div>
                    <p class="blog-text3">Лучшие интерьерные решения для офисов </p>
                    <div class="data3">
                        <p>25 Декабрь,2022 </p>
                        <button class="btn-blog3">&gt</button>
                    </div>
                </div>
            </div>
        </section>

        <footer
                logo1="require('@/assets/imges/Logo 1.png')"
                logo2="require('@/assets/imges/ikon 1.png')" 
                logo3="require('@/assets/imges/icon 2.png')"
                :pageLinks="navLinks"
                :contacts="contactInfo"></footer>
    </div>
</template>

<script>
import header from './header.vue';
import footer from './footer.vue';
export default {
    components: {
        header,
        footer,

    },
    data() {
        return {
            navLinks: [
                { name: 'Домой', href: 'page3.vue' },
                { name: 'Проект', href: 'page4.vue'},
                { name: 'Блок', href: 'page5.vue'}
            ],
            contactInfo: {
                adress: '55 East Birchwood Ave. <br> Brooklyn, New York 11201',
                email: 'contact@interno.com',
                phone: '(123) 456-7890'
            }
        };
    }
};

</script>

<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Jost:ital,wght@0,100..900;1,100..900&family=Noto+Sans:ital,wght@0,100..900;1,100..900&display=swap');

* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    /* Correction: use border-box instead of 0 */
    text-decoration: none;
}

.conteiner {
    max-width: 1200px;
    margin: auto;
}

.banner-conteiner {
    margin-top: 50px;
    max-height: 750px;
}

.banner {
    width: 100%;

}

.banner-conteiner {
    position: relative;
}

.content-banner {
    position: absolute;
    top: 30%;
    left: 200px;
    width: 600px;
    height: 246px;


}

.content-banner h1 {
    font-size: 65px;
    color: rgb(41, 47, 54);
    font-family: "DM Serif Display", serif;

}

.content-banner p {
    font-size: 22px;
    font-weight: 400px;
    font-family: "Jost", sans-serif;
    color: rgb(77, 80, 83);
}

.btn-banner {
    width: 180px;
    height: 75px;
    font-size: 18px;
    font-weight: 600;
    background: rgb(41, 47, 54);
    font-family: "Jost", sans-serif;
    color: rgb(255, 255, 255);
    cursor: pointer;
    border: none;
    border-radius: 30px;
    margin-top: 20px;
}

.project {
    margin-top: 50px;
}

.project-text {
    text-align: center;
    margin-top: 70px;
    margin-bottom: 50px;
}

.project-text h1 {
    font-size: 50px;
    font-family: "DM Serif Display", serif;
    color: rgb(41, 47, 54);
}

.project-text p {
    font-size: 22px;
    font-family: "Jost", sans-serif;
    color: rgb(77, 80, 83);
}

.project-imge image {
    width: 525px;
    height: 548px;
}

.project-imge {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}

.project-imge button {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    border: none;
    color: rgb(30, 28, 28);
    cursor: pointer;
    font-size: 20px;
}

.text-button {
    display: flex;
    justify-content: space-between;
    font-family: "Jost", sans-serif;
    color: rgb(41, 47, 54);
    margin-top: 20px;
    margin-bottom: 20px;
}

.counter {
    height: 200px;
    background-color: rgb(244, 240, 236);
    font-family: "Jost", sans-serif;
}

.allnumber image {
    width: 77px;
    height: 106px;
}

.allnumber {
    height: 200px;
    display: flex;
    justify-content: space-around;
    align-items: center;

}

.allnumber p {
    color: rgb(77, 80, 83);
    font-family: Jost;
    font-size: 22px;
    font-weight: 400;
    margin-top: 20px;
}


.blog-title {
    text-align: center;
}

.blog-title h1 {
    font-family: DM Serif Display;
    color: rgb(41, 47, 54);
    font-size: 50px;
    font-weight: 400;
    margin-top: 96px;
}

.blog-title p {
    color: rgb(77, 80, 83);
    font-family: Jost;
    font-size: 22px;
    font-weight: 400;

}

.blog-images {
    display: flex;
    justify-content: space-between;
    margin-top: 52px;

}

.blog-imge1,
.blog-imge2,
.blog-imge3 {
    position: relative;
    box-sizing: border-box;
    border: 1px solid rgb(231, 231, 231);
    border-radius: 62px;
    width: 380px;
    height: 500px;
}

.blog-imge2 {
    background-color: rgb(244, 240, 236);
    ;
}

.blog-imge1 img {
    width: 340px;
    height: 300px;
    margin: 20px;
}

.blog-imge2 img {
    width: 340px;
    height: 300px;
    margin: 20px;
}

.blog-imge3 img {
    width: 340px;
    height: 300px;
    margin: 20px;
}


.tag {
    position: absolute;
    border-radius: 8px 8px 8px 0px;
    background: rgb(255, 255, 255);
    background-color: rgb(255, 255, 255);
    width: 124px;
    height: 41px;
    top: 53%;
    left: 40px;
}

.tag2 {
    position: absolute;
    border-radius: 8px 8px 8px 0px;
    background: rgb(255, 255, 255);
    background-color: rgb(255, 255, 255);
    width: 124px;
    height: 41px;
    top: 55%;
    left: 40px;
}

.tag3 {
    position: absolute;
    border-radius: 8px 8px 8px 0px;
    background: rgb(255, 255, 255);
    background-color: rgb(255, 255, 255);
    width: 124px;
    height: 41px;
    top: 55%;
    left: 40px;
}

.tag p {
    color: rgb(77, 80, 83);
    font-family: Jost;
    font-size: 16px;
    font-weight: 400;
    text-align: center;
    padding-top: 10px;
}

.tag2 p {
    color: rgb(77, 80, 83);
    font-family: Jost;
    font-size: 16px;
    font-weight: 400;
}

.tag3 p {
    color: rgb(77, 80, 83);
    font-family: Jost;
    font-size: 16px;
    font-weight: 400;
}

.blog-text1,
.blog-text2,
.blog-text3 {
    color: rgb(41, 47, 54);
    font-family: DM Serif Display;
    font-size: 25px;
    font-weight: 400;
    padding-left: 20px;
}

.data,
.data2,
.data3 {
    display: flex;
    justify-content: space-between;
    margin: 20px;
    color: rgb(77, 80, 83);
    font-family: Jost;
    font-size: 16px;
    font-weight: 400;
}

.btn-blog1,
.btn-blog2,
.btn-blog3 {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: none;
    color: rgb(30, 28, 28);
    cursor: pointer;
    font-size: 20px;
    background-color: rgb(244, 240, 236);
}

.btn-blog2 {
    background-color: rgb(255, 255, 255);
}
</style>