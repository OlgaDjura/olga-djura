<template>
    <footer>
        <div class="footer">
            <div class="logos">
                <img :src="logo1" alt="interno" class="interno"><br><br>
                <img :src="logo2" alt="bird" class="bird">
                <img :src="logo3" alt="in" class="in">
            </div>
            <div class="footer-infor1">
                <h4>Страницы</h4>
                <ol>
                    <li v-for="(link, index) in pageLinks" :key="index">
                        <a :href="link.href">{{ link.name }}</a>
                    </li>
                </ol>
            </div>

            <div class="footer-infor2">
                <h4>Контакты</h4>
                <ol>
                    <li>{{ contacts.address }}</li>
                    <li>{{ contacts.email }}</li>
                    <li>{{ contacts.phone }}</li>
                </ol>
            </div>
        </div>
    </footer>
</template>
<script>
export default {
    props: {
        logo1: {
            type: String,
            required: true
        },
        logo2: {
            type: String,
            required: true
        },
        logo3: {
            type: String,
            required: true
        },
        pageLinks: {
            type: Array,
            required: true
        },
        contacts: {
            type: Object,
            required: true
        }
    }
}
</script>

<style scoped>
.footer {
    margin-top: 50px;
    display: flex;
    justify-content: space-between;
}

.in {
    padding-left: 60px;

}

.footer ol {
    list-style-type: none;
    text-decoration: none;
}

.interno {
    width: 180px;
    height: 50px;
}

.footer-infor1 li,
.footer-infor2 li {
    padding: 10px 0;
    color: rgb(77, 80, 83);
    font-family: Jost;
    font-size: 22px;
    font-weight: 400;
}

.footer-infor1 h4,
.footer-infor2 h4 {
    margin-bottom: 10px;
    color: rgb(41, 47, 54);
    font-family: DM Serif Display;
    font-size: 25px;
    font-weight: 400;
}

.footer-infor1 a {
    color: rgb(77, 80, 83);
}
</style>