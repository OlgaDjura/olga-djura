<template>
<div class="container">
    <header logo="require('@/assets/imge/Logo 1.png')" :links="navLinks"></header>
        <section class="section1">
            <div class="page3-banner">
                <img class="page3-banner" src="require('@/assets/imges/page3-benner.png')">
            </div>
        </section>
        <section class="section2">
            <div class="all-content-page3">
                <div class="blog-page3">
                    <div class="blog1-page3">
                        <h1>Создадим лучший макет <br> перепланировки</h1>
                        <img src="require('@/assets/imges/page3-imge1-blog.png')" alt="" class="imge-blog1-page3">
                        <div class="data-blog1-page3">
                            <p>26 Декабря,2022</p>
                            <p>Интерьер/Домой/Декор</p>
                        </div>
                        <p class="text-blog1-page3">В своей статье от 1994-го года журнал «Before & After» отследил фразу «Lorem ipsum ...» до
                            философского трактата Цицерона О пределах добра и зла, написанного в 45 году до нашей эры на
                            латинском языке.
                            В оригинале текст выглядит так «Neque porro quisquam est qui dolorem ipsum quia dolor sit
                            amet, consectetur, adipisci velit ...», и переводится как «Нет никого, кто любил бы свою
                            боль, кто искал бы ее и хотел бы чтобы она была у него. Потому что это боль...»</p>
                    </div>
                    <div class="blog2-page3">
                        <h1>,,</h1>
                        <h2>Какая-то умная и красивая <br> ...цитата </h2>
                    </div>
                    <div class="blog3-page3">
                        <h1>Design sprints are great</h1>
                        <p>В оригинале текст выглядит так «Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit ...», и переводится как «Нет никого, кто любил бы свою боль, кто искал бы ее и хотел бы чтобы она была у него. Потому что это боль...»</p>
                        <ol class="list-page3">
                            <li>С того времени этот, похожий на латинский, текст стал стандартом в печатной промышленности для примеров шрифтов и текстов.</li>
                            <li>С того времени этот, похожий на латинский, текст стал стандартом в печатной промышленности для примеров шрифтов и текстов.</li>
                            <li> С того времени этот, похожий на латинский, текст стал стандартом в печатной промышленности для примеров шрифтов и текстов.</li>
                        </ol>
                        <img src="require('@/assets/imges/page3-imge2-blog.png')" alt="" class="imge-blog3-page3">
                        <p>В своей статье от 1994-го года журнал «Before & After» отследил фразу «Lorem ipsum ...» до философского трактата Цицерона О пределах добра и зла, написанного в 45 году до нашей эры на латинском языке.</p>
                    </div>
                </div>
                <div class="tag-btn-page3">
                    <h3>Теги</h3>
                    <button class="btn1-page3">Кухня</button>
                    <button class="btn2-page3">Спальня</button>
                    <button class="btn3-page3">Здание</button>
                    <button class="btn4-page3 ">Архитектура</button>
                    <button class="btn5-page3">Планировка</button>
                    <button class="btn6-page3">Спальня</button>
                </div>
            </div>
        </section>
        <footer
                logo1="require('@/assets/imges/Logo 1.png')"
                logo2="require('@/assets/imges/ikon 1.png')" 
                logo3="require('@/assets/imges/icon 2.png')"
                :pageLinks="navLinks"
                :contacts="contactInfo"></footer>
    </div>
</template>

<script>
import header from './header.vue';
import footer from './footer.vue';
export default {
    name: 'page3',
    components: {
    header,
    footer,
    },
    data() {
        return {
            navLinks: [
                { name: 'Домой', href: 'page3.vue' },
                { name: 'Проект', href: 'page4.vue'},
                { name: 'Блок', href: 'page5.vue'}
            ],
            contactInfo: {
                adress: '55 East Birchwood Ave. <br> Brooklyn, New York 11201',
                email: 'contact@interno.com',
                phone: '(123) 456-7890'
            }
        };
    }
};
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Jost:ital,wght@0,100..900;1,100..900&display=swap');

* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    /* Correction: use border-box instead of 0 */
    text-decoration: none;
}

.container {
    max-width: 1200px;
    margin: auto;

}

.page3-banner {
    width: 1920px;
    height: 356px;
    margin-left: -180px;
}

.all-content-page3 {
    margin-top: 100px;
}

.blog-page3 {
    width: 800px;
}

.blog1-page3 h1 {
    color: rgb(41, 47, 54);
    font-family: DM Serif Display;
    font-size: 50px;
    font-weight: 400;

}

.imge-blog1-page3 {
    width: 799px;
    height: 539px;
    margin-top: 30px;
}

.data-blog1-page3 p {
    display: block;
    color: rgb(77, 80, 83);
    font-family: Jost;
    font-size: 16px;
}

.data-blog1-page3 {
    display: flex;
    justify-content: space-between;
    margin-top: 50px;
    margin-bottom: 50px;
}

.text-blog1-page3 {
    color: rgb(77, 80, 83);
    font-family: Jost;
    font-size: 22px;
}

.blog2-page3 {
    margin-top: 50px;
    width: 799px;
    height: 267px;
    border-radius: 50px;
    background: rgb(244, 240, 236);
    position: relative;
}

.blog2-page3 h1 {
    display: block;
    position: absolute;
    color: rgb(205, 162, 116);
    font-family: DM Serif Display;
    font-style: italic;
    font-size: 200px;
    top: -40%;
    right: 40%;

}

.blog3-page3 {
    margin-top: 50px;
}

.blog2-page3 h2 {
    display: block;
    position: absolute;
    color: rgb(205, 162, 116);
    font-family: DM Serif Display;
    font-style: italic;
    font-size: 25px;
    top: 50%;
    right: 30%;
}

.blog3-page3 h1 {
    color: rgb(41, 47, 54);
    font-family: DM Serif Display;
    font-size: 50px;
}

.blog3-page3 p {
    color: rgb(77, 80, 83);
    font-family: Jost;
    font-size: 22px;
}

.blog3-page3 ol {
    margin-top: 50px;
    margin-bottom: 50px;
    list-style: none;
    counter-reset: list-counter;
}

.list-page3 li {
    color: rgb(77, 80, 83);
    font-family: Jost;
    font-size: 22px;
    counter-increment: list-counter;
    position: relative;
    padding-left: 20px;
    margin-bottom: 30px;
}

.list-page3 li::before {
    color: rgb(205, 162, 116);
    font-size: 20px;
    content: counter(list-counter) "";
    position: absolute;
    left: -5px;
}

.imge-blog3-page3 {
    height: 400px;
    width: 800px;
    margin-bottom: 50px;
}

.tag-btn-page3 h3 {
    color: rgb(41, 47, 54);
    font-family: DM Serif Display;
    font-size: 25px;
    margin-bottom: 30px;
}

.tag-btn-page3 {
    width: 345px;
height: 200px;
}

.tag-btn-page3 button {
    cursor: pointer;
    border: none;
    border-radius: 10px;
    margin-top: 20px;
    font-family: Jost;
    font-size: 18px;
}

.btn1-page3 {
    width: 106px;
    height: 41px;
    color: rgb(255, 255, 255);

    background-color:
        rgb(41, 47, 54);
}

.btn2-page3 {
    width: 131px;
    height: 41px;
    background-color: rgb(244, 240, 236);
    color: rgb(41, 47, 54);
}

.btn3-page3 {
    background-color: rgb(244, 240, 236);
    width: 123px;
    height: 41px;
    color: rgb(41, 47, 54);

}

.btn4-page3 {
    background-color: rgb(244, 240, 236);
    width: 158px;
    height: 41px;
    color: rgb(41, 47, 54);
}

.btn5-page3 {
    background-color: rgb(244, 240, 236);
    width: 160px;
    height: 41px;
    color: rgb(41, 47, 54);
}

.btn6-page3 {
    background-color: rgb(244, 240, 236);
    width: 131px;
    height: 41px;
    color: rgb(41, 47, 54);
}

.all-content-page3 {
    display: flex;
    justify-content: space-between;
}

</style>