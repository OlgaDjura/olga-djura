<template>
    <div class="News">
        <div class="news-title">
            <h1>Статьи & Новости</h1>
        </div>
        <div class="News-images">
            <div v-for="(article, index) in articles" :key="index" class="news-imge">
                <img class="imge-news" :src="require(`@/assets/imges/${article.image}`)" :alt="article.title">
                <div class="tag-news">
                    <p>{{ article.tag }}</p>
                </div>
                <p class="news-text">{{ article.text }}</p>
                <div class="data-news">
                    <p>{{ article.date }}</p>
                    <button class="btn-news">&gt</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            articles: [
                {
                    image: 'ImageBlog1.png',
                    tag: 'Дизайн кухни',
                    text: 'Создадим лучший макет перепланировки',
                    date: '26 Декабрь,2022'
                },
                {
                    image: 'ImageBlog2.png',
                    tag: 'Дизайн для жизни',
                    text: 'Лучшие интерьерные идеи по низкой цене',
                    date: '22 Декабрь,2022'
                },
                {
                    image: 'ImageBlog3.png',
                    tag: 'Дизайн интерьера',
                    text: 'Лучшие интерьерные решения для офисов',
                    date: '25 Декабрь,2022'
                },
            ]
        };
    }
};
</script>