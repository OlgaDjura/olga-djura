<template>
    <header>
        <div class="header-container">
            <img class="logoMenu" :src="logo" alt="logo">
            <nav>
                <ul class="menu">
                    <li v-for="(link, index) in links" :key="index">
                        <a :href="link.href">{{ link.name }}</a>
                    </li>
                </ul>
            </nav>
        </div>
    </header>
</template>

<script>
export default {
    props: {
        logo: {
            type: String,
            required: true
        },
        links: {
            type: Array,
            required: true
        }
    }
}
</script>

<style scoped>
.logoMenu {

max-width: 177px;
padding: 0;
/*max-height: 50px;*/

}

.header-container {
display: flex;
justify-content: space-between;
align-items: center;
max-height: 50px;
margin-top: 50px;
margin-bottom: 50px;
}

.menu {
list-style-type: none;
display: flex;
position: relative;
}

.menu li {
margin-left: 30px;
}

.menu a {
color: rgb(41, 47, 54);
font-family: Jost;
font-size: 20px;
}
</style>