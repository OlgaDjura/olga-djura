<template>
<div class="container">
    <header logo="require('@/assets/imge/Logo 1.png')" :links="navLinks"></header>
        <section class="section1">
            <div class="page5-banner">
                <img class="page5-banner" src="require('@/assets/imges/banner-page5.jpg')">
            </div>
        </section>
        <section class="section2">
            <div class="text-page5">
                <h1>Минималистичные <br> спальни</h1>
                <p>В своей статье от 1994-го года журнал «Before & After» отследил фразу «Lorem ipsum ...» до философского трактата Цицерона О пределах добра и зла, написанного в 45 году до нашей эры на латинском языке. <br> <br>

                    В оригинале текст выглядит так «Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit ...», и переводится как «Нет никого, кто любил бы свою боль, кто искал бы ее и хотел бы чтобы она была у него. Потому что это боль...».</p>
            </div>
            <div class="imge-page5">
                <imageSlider></imageSlider>
            </div> 
            
        </section>

        <footer
                logo1="require('@/assets/imges/Logo 1.png')"
                logo2="require('@/assets/imges/ikon 1.png')" 
                logo3="require('@/assets/imges/icon 2.png')"
                :pageLinks="navLinks"
                :contacts="contactInfo"></footer>

    </div>
</template>

<script>
import header from './header.vue';
import footer from './footer.vue';
import imageSlider from './imageSlider.vue';
export default {
    name: 'page5',
    components:  {
        header,
        footer,
        imageSlider,
    },
    data() {
        return {
            navLinks: [
                { name: 'Домой', href: 'page3.vue' },
                { name: 'Проект', href: 'page4.vue'},
                { name: 'Блок', href: 'page5.vue'}
            ],
            contactInfo: {
                adress: '55 East Birchwood Ave. <br> Brooklyn, New York 11201',
                email: 'contact@interno.com',
                phone: '(123) 456-7890'
            }
        };
    }
};
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Jost:ital,wght@0,100..900;1,100..900&display=swap');


* {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    /* Correction: use border-box instead of 0 */
    text-decoration: none;
}

.container {
    max-width: 1200px;
    margin: auto;
}

.page5-banner {
    width: 1920px;
height: 400px;
margin-left: -180px;
margin-top: 30px;
}

.text-page5 {
    margin-left: 20%;
    margin-top: 200px;
    width: 700px;
height: 450px;

}
.text-page5 h1 {
    color: rgb(41, 47, 54);
font-family: DM Serif Display;
font-size: 50px;
margin-bottom: 20px;
}
.text-page5 p {
    color: rgb(77, 80, 83);
font-family: Jost;
font-size: 22px;
}
.page5-imge {
    margin-top: 50px;
    height: 800px;
}
.imge-page5 {
    position: relative;
    margin-bottom: 150px;
}
.zoom {
    position: absolute;
    top: 45%;
    right: 45%;
    width: 150px;
}
</style>