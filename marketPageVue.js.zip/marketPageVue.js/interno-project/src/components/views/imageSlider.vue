<template>
    <div class="image-slider">
        <div class="slides">
            <div v-for="(image, index) in images" :key="index" class="slide"
                :class="{ active: currentIndex === index }">
                <img :src="image" alt="Slider image">
            </div>
        </div>
        <div class="button-container">
            <button v-for="(image, index) in images" :key="index" class="dot-button"
                :class="{ active: currentIndex === index }" @click="goToSlide(index)"></button>
        </div>
        <button class="prev" @click="prev">Previous</button>
        <button class="next" @click="next">Next</button>
    </div>
</template>

<script>
export default {
    data() {
        return {
            currentIndex: 0,
            images: [
                '/interno-project/src/assets/imges/Image-page5.png' //единстенное изображение в проете для этой страницы
            ],
        };
    },
    methods: {
        next() {
            this.currentIndex = (this.currentIndex + 1) % this.images.length;
        },
        prev() {
            this.currentIndex = (this.currentIndex - 1 + this.images.length) % this.images.length;
        },
        goToSlide(index) {
            this.currentIndex = index;
        },
    },
};
</script>

<style>
.image-slider {
    position: relative;
    width: 100%;
    overflow: hidden;
}

.slides {
    display: flex;
    transition: transform 0.5s ease;
}

.slide {
    min-width: 100%;
    transition: opacity 0.5s ease;
    opacity: 0;
}

.slide.active {
    opacity: 1;
}

button {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
}

button:hover {
    cursor: pointer;
}

/* Стили для кнопок "Previous" и "Next" */
.prev {
    left: 10px;
}

.next {
    right: 10px;
}

/* Стили для круглых кнопок под изображениями */
.button-container {
    display: flex;
    justify-content: center;
    margin-top: 10px;
}

.dot-button {
    background-color: white;
    border: 2px solid black;
    border-radius: 50%;
    width: 12px;
    height: 12px;
    margin: 0 5px;
    cursor: pointer;
    opacity: 0.5;
    /* Общее состояние для кнопок */
}

.dot-button.active {
    opacity: 1;
    /* Активная кнопка более заметная */
}
</style>